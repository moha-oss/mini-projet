import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    //colors
    public static final String TEXT_RED = "\u001B[31m";
    public static final String TEXT_RESET = "\u001B[0m";
    public static final String TEXT_GREEN = "\u001B[32m";
    ArrayList <Employe> listeEmploye=new ArrayList<Employe>();
    Scanner s=new Scanner(System.in);

    //Ajouter employé
    public void ajouterEmploye(){
        Employe e=new Employe();
        String prenomvalide;
        System.out.print("Donner le matricule:");
        int matr=s.nextInt();
        System.out.print("Donner le nom:");
        String nom=s.next().toUpperCase();
        System.out.print("Donner le prenom:");
        String prenom=s.next();
        prenomvalide=prenom.substring(0,1).toUpperCase()+prenom.substring(1).toLowerCase();
        System.out.print("Donner l'age:");
        short age =s.nextShort();
        System.out.print("Donner le salaire:");
        int sal=s.nextInt();

        e.setMatricule(matr);e.setNom(nom);e.setPrenom(prenomvalide);e.setAge(age);e.setSalaire(sal);
        if(listeEmploye.contains(e.getMatricule())){
            System.out.println(TEXT_RED+"L'employé existe!!!"+TEXT_RESET);
        }else {listeEmploye.add(e);
            System.out.println(TEXT_GREEN+"Ajouter avec succeé"+TEXT_RESET);
        }
    }

    //Modifier Employé
    public void modifierEmploye(){
        Employe e=new Employe();
        System.out.println("Donner le matricule de l'employé:");
        int matr=s.nextInt();
        for (Employe i:listeEmploye) {
            String prenomvalide;
            if (i.getMatricule()==matr){
                System.out.print("Donner le neauvau nom:");
                String nom=s.next().toUpperCase();
                System.out.print("Donner le neauvau prenom:");
                String prenom=s.next();
                prenomvalide=prenom.substring(0,1).toUpperCase()+prenom.substring(1).toLowerCase();
                System.out.print("Donner le neauvau age:");
                short age=s.nextShort();
                System.out.print("Donner le neauvau salaire:");
                int sal=s.nextInt();
                i.setNom(nom);i.setPrenom(prenomvalide);i.setAge(age);i.setSalaire(sal);
                System.out.println(TEXT_GREEN+"Modification avec succeé"+TEXT_RESET);
            }else {
                System.out.println(TEXT_RED+"L'employe n'existe pas!!!"+TEXT_RESET);
            }
        }
    }

    //Suprimmer Employé
    public void suprimerEmploye() {
        Employe e=new Employe();
        System.out.print("Donner le matricule de l'employé:");
        int matr = s.nextInt();
        int count=0;
        for (Employe i : listeEmploye) {
            if (i.getMatricule() == matr) {
                listeEmploye.remove(i);
                System.out.println(TEXT_GREEN+"Suprission avec succeé"+TEXT_RESET);
                count++;
            }
        }
        if (count==0){
            System.out.println(TEXT_RED+"L'employe n'existe pas!!!"+TEXT_RESET);
        }
    }

    //Afficher Employé
    public void afficherEmploye(){
        System.out.print("Donner le matricule de l'employé:");
        int matr = s.nextInt();
        System.out.println("_________________________________________________________________");
        if(listeEmploye.isEmpty()){
            System.out.println(TEXT_RED+"La liste est vide!!!"+TEXT_RESET);
        }else{
            for (Employe i : listeEmploye) {
                if (i.getMatricule() == matr) {
                    System.out.println("Matricule:" + i.getMatricule() + "\nNom complet:" + i.getNom() + " " + i.getPrenom()
                            + "\nAge:" + i.getAge() + "\nSalaire:" + i.getSalaire());
                } else {
                    System.out.println(TEXT_RED + "L'emplyé n'xiste pas!!!" + TEXT_RESET);
                }
            }
        }
    }

    //Afficher tous
    public void affichertousEmploye(){
        if(listeEmploye.isEmpty()){
            System.out.println(TEXT_RED+"La liste est vide!!!"+TEXT_RESET);
        } else{
            for (Employe i : listeEmploye) {
                if (listeEmploye.size() != 0) {
                    System.out.println("Matricule:"+i.getMatricule()+"\nNom complet:"+i.getNom()+" "+i.getPrenom()
                            +"\nAge:"+i.getAge()+"\nSalaire:"+i.getSalaire()+"\n************************************");
                }
            }
        }
    }

    //Salaire>10000
    public void elveSalaire(){
        int count=0;
        for (Employe i:listeEmploye) {
            if (i.getSalaire()>10000) {
                count++;
            }
        }
        if (count>0){
            System.out.println("Le nombre d'employés est:"+count);
        }else {
            System.out.println(TEXT_RED+"acun employé!!!"+TEXT_RESET);
        }
    }

    //Plus agé
    public short plusAge(){
        Employe e=new Employe();
        short maxage=e.getAge();
        for (Employe i:listeEmploye) {
            if(i.getAge()>maxage){
                maxage=i.getAge();
            }
        }
        return maxage;
    }

    //moin agé
    public short moinAge(){
        Employe e=new Employe();
        short minage=listeEmploye.get(0).getAge();
        for (Employe i:listeEmploye) {
            if(i.getAge()<minage){
                minage=i.getAge();
            }
        }
        return minage;
    }

    //quitter
    public void quitter(){
        System.out.println("Fin de programme.");
        System.exit(0);
    }
    public void menu(){
        System.out.println("\n_________________________________________________________________");
        System.out.println(TEXT_RED+"****************Menu de programme****************"+TEXT_RESET);
        System.out.println("1-Ajouter un employé:");
        System.out.println("2-Modifier un employé:");
        System.out.println("3-Suprimmer un employé:");
        System.out.println("4-Afficher un employé:");
        System.out.println("5-Afficher tous les employé:");
        System.out.println("6-Nombre d'employé avc un salaire>10000:");
        System.out.println("7-Afficher l'employer le plus agé:");
        System.out.println("8-Afficher l'employer le moin agé:");
        System.out.println("9-Quitter:");
        System.out.println("_________________________________________________________________");
    }
}