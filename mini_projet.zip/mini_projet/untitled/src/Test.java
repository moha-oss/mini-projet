import java.util.Scanner;

public class Test {
    public static final String TEXT_RED = "\u001B[31m";
    public static final String TEXT_RESET = "\u001B[0m";
    static Scanner ss=new Scanner(System.in);
    public static void main(String[] args){
        Main main=new Main();
        int i=0;
        do {
            main.menu();
            System.out.print("Donner votre choix:");
            int choix=ss.nextInt();
            System.out.println("_________________________________________________________________");
            if (choix==1){
                main.ajouterEmploye();
            }else if (choix==2){
                main.modifierEmploye();
            } else if (choix==3) {
                main.suprimerEmploye();
            } else if (choix==4) {
                main.afficherEmploye();
            } else if (choix==5) {
                main.affichertousEmploye();
            } else if (choix==6) {
                main.elveSalaire();
            } else if (choix==7) {
                System.out.println("Le plus Agé est:"+main.plusAge());
            } else if (choix==8) {
                System.out.println("Le moin Agé est:"+main.moinAge());
            } else if (choix==9) {
                main.quitter();
            } else {
                System.out.println(TEXT_RED+"Choix Invalide!!!"+TEXT_RESET);
            }
        }while (i==0);
    }
}
